<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="euc-kr" />
<meta name="title" content="�����ø� :: ������ �庸��, �����ø�" />
<meta name="description" content="Love Food, Love Life. �����ø�! ���� ��Ȯ ä��, ����, ���� ���ı��� ���� ��ħ �� �տ��� ������!" />
<meta property="og:title" content="�����ø� :: ������ �庸��, �����ø�" />
<meta property="og:description" content="Love Food, Love Life. �����ø�! ���� ��Ȯ ä��, ����, ���� ���ı��� ���� ��ħ �� �տ��� ������!" />
<meta property="og:image" content="https://res.kurly.com/images/marketkurly/logo/logo_sns_marketkurly.jpg" />
<meta property="og:url" content="https://www.kurly.com/shop/main/index.php?" />
<meta property="og:type" content="website" />
<meta property="og:site_name" content="www.kurly.com" />
<meta name="keywords" content="���̾�Ʈ, �Ĵ�, �߰�����, �丮, ġ�ƹ�Ÿ, ������, �丮, ������, ���̾�Ʈ����, ������, �ǰ�������" />
<title>�����ø� :: ������ �庸��, �����ø�</title>
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0" />
<meta name="naver-site-verification" content="58ff7c242d41178131208256bfec0c2f93426a1d" />
<meta name="facebook-domain-verification" content="tyur3wmoos7t63tpkb7zosur6p98m1" />

<script src="https://js.sentry-cdn.com/c1f07ee4a3fd45d5aa2ef4983ca9ad43.min.js" crossorigin="anonymous"></script>
<script>
  var environment = 'production';

  Sentry.onLoad(function() {
    Sentry.init({
      environment: environment,
      denyUrls: [
        /localhost/i,
        /dev\.kurly\.com/i
      ],
      sampleRate: 0.1,
    });
  });
</script>

<script src="/asset/js/common.bundle.js?ver=1.38.2"></script>
<script type="text/javascript" src="https://res.kurly.com/js/lib/jquery-1.10.2.min.js"></script>
<link rel="shortcut icon" href="https://res.kurly.com/images/marketkurly/logo/favicon_v2.png" type="image/x-icon">
<link rel="apple-touch-icon" sizes="57x57" href="https://res.kurly.com/images/marketkurly/logo/ico_57.png">
<link rel="apple-touch-icon" sizes="60x60" href="https://res.kurly.com/images/marketkurly/logo/ico_60.png">
<link rel="apple-touch-icon" sizes="72x72" href="https://res.kurly.com/images/marketkurly/logo/ico_72.png">
<link rel="apple-touch-icon" sizes="76x76" href="https://res.kurly.com/images/marketkurly/logo/ico_76.png">
<link rel="apple-touch-icon" sizes="114x114" href="https://res.kurly.com/images/marketkurly/logo/ico_114.png">
<link rel="apple-touch-icon" sizes="120x120" href="https://res.kurly.com/images/marketkurly/logo/ico_120.png">
<link rel="apple-touch-icon" sizes="144x144" href="https://res.kurly.com/images/marketkurly/logo/ico_144.png">
<link rel="apple-touch-icon" sizes="152x152" href="https://res.kurly.com/images/marketkurly/logo/ico_152.png">
<link rel="apple-touch-icon" sizes="180x180" href="https://res.kurly.com/images/marketkurly/logo/ico_180.png">
<link rel="icon" type="image/png" sizes="32x32" href="https://res.kurly.com/images/marketkurly/logo/ico_32.png">
<link rel="icon" type="image/png" sizes="192x192" href="https://res.kurly.com/images/marketkurly/logo/ico_192.png">
<link rel="icon" type="image/png" sizes="16x16" href="https://res.kurly.com/images/marketkurly/logo/ico_16.png">
<script>
sessionStorage.setItem('user_no', '')
sessionStorage.setItem('apiDomainV2', '')

var jwtToken = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJjYXJ0X2lkIjoiYTdiM2Y2NmMtZjUzZC00MWU2LWIzYjgtYjkyYjMzMDgwNWRlIiwiaXNfZ3Vlc3QiOnRydWUsInV1aWQiOm51bGwsIm1fbm8iOm51bGwsIm1faWQiOm51bGwsImxldmVsIjpudWxsLCJzdWIiOm51bGwsImlzcyI6Imh0dHA6Ly9ta3dlYi5hcGkua3VybHkuc2VydmljZXMvdjMvYXV0aC9ndWVzdCIsImlhdCI6MTYyOTk1ODEyNCwiZXhwIjoxNjI5OTYxNzI0LCJuYmYiOjE2Mjk5NTgxMjQsImp0aSI6IlY2OWFoN1hnN0VHcFhCWHkifQ.6HqYm2CgpeqIf1rYUGXimdw4YvbLhtHp_A-o5a166uo';
var apiDomain = 'https://api.kurly.com';
var GD_ISMEMBER = !!Number('0');
var checkIsApp = true;// �ش罺ũ��Ʈ�������� ��üũ���뺯���߰� ����.�ۿ��� ���ʿ��� ȣ������
</script>
<script src="https://ssl.daumcdn.net/dmaps/map_js_init/postcode.v2.js"></script>
<script src="/shop/data/skin/designgj/thefarmers.js?ver=1.38.2"></script>
<script src="/shop/data/skin/designgj/common.js?ver=1.38.2"></script>
<script src="/shop/data/skin/designgj/polify.js?ver=1.38.2"></script>
<script src="/shop/data/skin/designgj/ui_v2.js?ver=1.38.2"></script>

<script src="//res.kurly.com/js/vue/xdomain.min.js" slave="https://api.kurly.com/xdomain?ver=1"></script>

<script src="//res.kurly.com/js/vue/es6-promise.min.js"></script>
<script src="//res.kurly.com/js/vue/es6-promise.auto.min.js"></script>

<script type="text/javascript" src="//res.kurly.com/js/vue/axios.min.js"></script>


<script src="//res.kurly.com/js/vue/vue.min.js"></script>
<script src="/common_js/axios.js?ver=1.38.2"></script>
<link rel="styleSheet" href="/shop/data/skin/designgj/normalize.css?ver=1.38.2">
<link rel="styleSheet" href="/shop/data/skin/designgj/section1.css?ver=1.38.2">
<link rel="styleSheet" href="/shop/data/skin/designgj/common.css?ver=1.38.2">

<script type="text/javascript" src="//wcs.naver.net/wcslog.js"></script>
<script type="text/javascript" src="/shop/lib/js/naverCommonInflowScript.js?Path=main/index.php&amp;Referer=&amp;AccountID=s_4f41b5625072&amp;Inflow=" id="naver-common-inflow-script"></script>


<script async src="https://www.googletagmanager.com/gtag/js?id=G-2K2GN0FFY0"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-2K2GN0FFY0', {
    'user_id' : 'a7b3f66c-f53d-41e6-b3b8-b92b330805de'
  });
</script>

<style>.async-hide { opacity: 0 !important} </style>
<script type="text/javascript">
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','//www.google-analytics.com/analytics.js','ga');

ga('create', 'UA-90734988-1', 'auto');//'UA-90734988-1'
<!-- KM-201 ������ : ���� ��Ƽ������&�±� �޴��� -->
ga('require', 'GTM-MRW9DRV');
(function(a,s,y,n,c,h,i,d,e){s.className+=' '+y;h.start=1*new Date;
    h.end=i=function(){s.className=s.className.replace(RegExp(' ?'+y),'')};
    (a[n]=a[n]||[]).hide=h;setTimeout(function(){i();h.end=null},c);h.timeout=c;
})(window,document.documentElement,'async-hide','dataLayer',4000,{'GTM-MRW9DRV':true});

(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'//www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-MRW9DRV');
<!-- End KM-201 ������ : ���� ��Ƽ������&�±� �޴��� -->

var uuidCheck = "";
var cookie_uuid = null;

function setCookieGa(cookieName, value){
	var exdays = 365;
	var exdate = new Date();
	exdate.setDate(exdate.getDate() + exdays);
	var cookieValue = escape(value) + ((exdays==null) ? "" : "; expires=" + exdate.toGMTString());
	document.cookie = cookieName + "=" + cookieValue +"; path=/;"
}

function getCookieGa(cookieName) {
	cookieName = cookieName + '=';
	var cookieData = document.cookie;
	var start = cookieData.indexOf(cookieName);
	var cookieValue = '';
	if(start != -1){
		start += cookieName.length;
		var end = cookieData.indexOf(';', start);
		if(end == -1)end = cookieData.length;
		cookieValue = cookieData.substring(start, end);
	}
	return unescape(cookieValue);
}

function deleteCookieGa(cookieName){
	var expireDate = new Date();
	//���� ��¥�� ��Ű �Ҹ� ��¥�� �����Ѵ�.
	expireDate.setDate( expireDate.getDate() - 1 );
	document.cookie = cookieName + "= " + "; expires=" + expireDate.toGMTString() + "; path=/";
}


/* �α��� */
if(uuidCheck !== "") {
	if( !getCookieGa('ga_uuid') ){
		setCookieGa('ga_uuid', uuidCheck);
	}else{
		if( getCookieGa('ga_uuid') !== uuidCheck){
			deleteCookieGa('ga_uuid');
			setCookieGa('ga_uuid', uuidCheck); /* �α��� �������Ű �߰� */
		}
	}
	ga('set', 'userId', uuidCheck);
	ga('send', 'pageview',{'dimension1':  uuidCheck});
}else{
	ga('send', 'pageview');
}

//edge browser correspondence
var disableSelection = true;
$(function(){
    $('input, textarea').on('focus', function(){
        disableSelection = false;
    }).on('blur', function(){
        disableSelection = true;
    });
});
</script>
<script>
(function(e,t){var n=e.amplitude||{_q:[],_iq:{}};var r=t.createElement("script")
;r.type="text/javascript"
;r.integrity="sha384-vYYnQ3LPdp/RkQjoKBTGSq0X5F73gXU3G2QopHaIfna0Ct1JRWzwrmEz115NzOta"
;r.crossOrigin="anonymous";r.async=true
;r.src="https://cdn.amplitude.com/libs/amplitude-5.8.0-min.gz.js"
;r.onload=function(){if(!e.amplitude.runQueuedFunctions){
	console.log("[Amplitude] Error: could not load SDK")}}
;var i=t.getElementsByTagName("script")[0];i.parentNode.insertBefore(r,i)
;function s(e,t){e.prototype[t]=function(){
	this._q.push([t].concat(Array.prototype.slice.call(arguments,0)));return this}}
	var o=function(){this._q=[];return this}
	;var a=["add","append","clearAll","prepend","set","setOnce","unset"]
	;for(var u=0;u<a.length;u++){s(o,a[u])}n.Identify=o;var c=function(){this._q=[]
			;return this}
	;var l=["setProductId","setQuantity","setPrice","setRevenueType","setEventProperties"]
	;for(var p=0;p<l.length;p++){s(c,l[p])}n.Revenue=c
	;var d=["init","logEvent","logRevenue","setUserId","setUserProperties","setOptOut","setVersionName","setDomain","setDeviceId", "enableTracking", "setGlobalUserProperties","identify","clearUserProperties","setGroup","logRevenueV2","regenerateDeviceId","groupIdentify","onInit","logEventWithTimestamp","logEventWithGroups","setSessionId","resetSessionId"]
	;function v(e){function t(t){e[t]=function(){
		e._q.push([t].concat(Array.prototype.slice.call(arguments,0)))}}
		for(var n=0;n<d.length;n++){t(d[n])}}v(n);n.getInstance=function(e){
		e=(!e||e.length===0?"$default_instance":e).toLowerCase()
		;if(!n._iq.hasOwnProperty(e)){n._iq[e]={_q:[]};v(n._iq[e])}return n._iq[e]}
	;e.amplitude=n})(window,document);

var amplitudeUid = uuidCheck;
if(amplitudeUid === null){
	amplitudeUid = 'a7b3f66c-f53d-41e6-b3b8-b92b330805de';
}
var appResult = {
	is_release_build: false,
	is_sess: false, // �α��� ����
  isSession: false,
	appCheck: false,
	device: 'pc',
  timestamp: parseInt("1629958124581", 10)
}

<!---->
<!---->
appResult.is_release_build = true;
<!---->

var webStatus = appResult;
/* appResult ���� */

<!---->
amplitude.getInstance().init("65bebb55595beb82e78d5d1ae808702c", amplitudeUid);
<!---->
</script>

<script src="/common_js/kurlytracker/kurlytracker.js?ver=1.38.2"></script>
<script>
  // KM-4988 : amplitude userProperties ������Ʈ
  var userProperties = {
    membership_level: '',
    cust_no: Number(''),
  };
  KurlyTracker.setUserProperties(userProperties);
</script>



<script src="/common_js/kurlytracker/facebookConversions.js?ver=1.38.2"></script>

<script src="/asset/js/useKurly/kurlyAPI.bundle.js"></script>
</head>
<body class="main-index" oncontextmenu="return false" ondragstart="return false" onselectstart="return !disableSelection">


<script src="//developers.kakao.com/sdk/js/kakao.min.js"></script>
<div id="wrap" class="">
<div id="pos_scroll"></div>
<div id="container">
<div id="header"><script>
  // ie10 ���� ������ �̵�
  var ieCheckAgent = navigator.userAgent.toLowerCase();
  if ( (navigator.appName === 'Netscape' && navigator.userAgent.search('Trident') !== -1) || (ieCheckAgent.indexOf("msie") !== -1) ) {
    if(navigator.appName !== 'Netscape'){
      location.href = "/shop/event/browserUpdate.php";
    }
  }
</script>

<div class="bnr_header" id="top-message">


<a href="https://www.kurly.com/shop/event/kurlyEvent.php?htmid=event/join/join_210825" id="eventLanding">
���� �����ϰ� �α��ǰ <b>100��</b>�� �޾ư�����!<img src="https://res.kurly.com/pc/ico/1908/ico_arrow_fff_84x84.png" class="bnr_arr">
<div class="bnr_top">
<div class="inner_top_close">
<button id="top-message-close" class="btn_top_bnr">�����ϰ� ���ùޱ�</button>
</div>
</div>
</a>
<script>
        // PROM-476 ������ : GA) �̺�Ʈ Ʈ��ŷ
        $('#eventLanding').on('click', function(){
          ga('send', 'event', 'click', 'general_header_sighup', location.href);
        });
      </script>
</div>
<script type="text/javascript">
    $(document).ready(function(){
      $("#top-message-close").on("click",function(){
        setCookie('top_msg_banner2','set_cookie',1)
      });
      if(getCookie('top_msg_banner2') == 'set_cookie'){
        $("#top-message").hide()
      }else{
        $("#top-message").show() ;
      }
    });

    function setCookie(cookieName, value, exdays){
      var exdate = new Date();
      exdate.setDate(exdate.getDate() + exdays);
      var cookieValue = escape(value) + ((exdays==null) ? "" : "; expires=" + exdate.toGMTString());
      document.cookie = cookieName + "=" + cookieValue +"; path=/;"
    }

    function getCookie(cookieName) {
      cookieName = cookieName + '=';
      var cookieData = document.cookie;
      var start = cookieData.indexOf(cookieName);
      var cookieValue = '';
      if(start != -1){
        start += cookieName.length;
        var end = cookieData.indexOf(';', start);
        if(end == -1)end = cookieData.length;
        cookieValue = cookieData.substring(start, end);
      }
      return unescape(cookieValue);
    }
  </script>

<div id="userMenu">
<user-menu-pc :login-check="loginCheck" :notification-item="notificationItem" :user-info="userInfo" :return-url="returnUrl"></user-menu-pc>
</div>
<script src="/common_js/usermenu_v1.js?ver=1.38.2"></script>
<script>
    $(document).ready(function(){

      userMenu.loginCheck = false;
    });
  </script>

<style>
  #headerLogo{position:relative;width:1050px;height:63px;margin:0 auto}
  #headerLogo .bnr_delivery{position:absolute;left:-1px;top:-28px;margin:auto;height:22px}
  #headerLogo .logo{position:absolute;left:50%;bottom:6px;width:200px;height:79px;margin-left:-100px}
  #headerLogo .logo img{display:block;width:103px;height:79px;margin:0 auto}
  #headerLogo .logo #gnbLogoContainer {margin:0 auto}
  #gnb.gnb_stop{position:fixed;z-index:300;left:0;top:0;width:100%}
  #gnb .gnb_kurly{position:relative;z-index:300;min-width:1050px;background-color:#fff;font-family:'Noto Sans';letter-spacing:-0.3px}
  #gnb .gnb_kurly:after{content:"";position:absolute;z-index:299;left:0;top:56px;width:100%;height:9px;background:url(https://res.kurly.com/pc/service/common/1902/bg_1x9.png) repeat-x 0 100%}
  #gnb .inner_gnbkurly{position:relative;width:1050px;height:56px;margin:0 auto}
  /* �˻�â */
  #gnb .gnb_search{position:absolute;right:108px;top:10px;width:242px}
  #gnb .gnb_search .inp_search{width:242px;height:36px;padding:0 60px 0 14px;border:1px solid #f7f7f6;border-radius:18px;background-color:#f7f7f7;font-family: 'Noto Sans';font-weight:400;font-size:12px;color:#666;line-height:16px;outline:none}
  #gnb .gnb_search .inp_search.focus{background-color:#fff;color:#333}
  #gnb .gnb_search .btn_search{position:absolute;right:5px;top:3px;width:30px;height:30px}
  /* ��ٱ��� */
  #gnb .cart_count{position:absolute;right:-5px;top:10px}
  #gnb .cart_count .inner_cartcount{text-align:center;font-weight:400}
  #gnb .cart_count .btn_cart{display:block;width:36px;height:36px;background:url(https://res.kurly.com/pc/service/common/2011/ico_cart.svg) no-repeat 50% 50%}
  #gnb .cart_count .btn_cart:hover{background:url(https://res.kurly.com/pc/service/common/2011/ico_cart_on.svg?v=1) no-repeat 50% 50%}
  #gnb .cart_count .num{display:none;position:absolute;left:19px;top:-1px;min-width:20px;height:20px;padding:0 5px;border:2px solid #fff;border-radius:10px;background-color:#5f0080;font-size:9px;color:#fff;line-height:15px;text-align:center;white-space:nowrap}
  #gnb .cart_count img{display:block;width:36px;height:36px;margin:0 auto}
  #gnb .cart_count .msg_cart{display:none;position:absolute;right:-7px;top:61px;width:348px;border:1px solid #ddd;background-color:#fff;/* opacity:0; */}
  #gnb .cart_count .inner_msgcart{display:block;overflow:hidden;padding:20px 0 20px 20px}
  #gnb .cart_count .msg_cart .thumb{float:left;width:46px;height:60px}
  #gnb .cart_count .msg_cart .desc{float:left;width:260px;padding:8px 0 0 20px;font-weight:700;font-size:14px;line-height:21px}
  #gnb .cart_count .msg_cart .desc.add{padding-top:0;margin-top:-5px;}
  #gnb .cart_count .msg_cart .tit{display:block;overflow:hidden;width:100%;color:#999;white-space:nowrap;text-overflow:ellipsis}
  #gnb .cart_count .msg_cart .name{overflow:hidden;float:left;max-width:178px;text-overflow:ellipsis}
  #gnb .cart_count .msg_cart .txt{display:block;padding-top:3px;color:#333}
  #gnb .cart_count .msg_cart .point{position:absolute;right:13px;top:-14px;width:20px;height:14px;background:url(https://res.kurly.com/pc/ico/1903/ico_layer_point.png) no-repeat 0 0}
  #gnb .cart_count .msg_cart .repeat{display:none}
  #gnb .cart_count .msg_cart .add .repeat{display:block}
  /* GNB���� */
  #gnb .gnb_main{overflow:hidden;width:1050px;margin:0 auto}
  #gnb .gnb_main .gnb{float:left;width:100%}
  #gnb .gnb_main .gnb li{float:left}
  #gnb .gnb_main .gnb .lst{background:none}
  #gnb .gnb_main .gnb a{overflow:hidden;float:left;width:124px;height:55px;padding:16px 0 0;font-size:16px;color:#333;line-height:20px;text-align:center}
  #gnb .gnb_main .gnb a .txt{font-weight:700}
  #gnb .gnb_main .gnb a:hover,
  #gnb .gnb_main .gnb a.on{font-weight:700;color:#5f0080}
  #gnb .gnb_main .gnb a:hover .txt{border-bottom:1px solid #5f0080}
  #gnb .gnb_main .menu1 a{width:168px}
  #gnb .gnb_main .menu1 .ico{float:left;width:16px;height:14px;margin:5px 14px 0 0;background:url(https://res.kurly.com/pc/service/common/1908/ico_gnb_all_off.png) no-repeat}
  #gnb .gnb_main .menu1 a.on .ico,
  #gnb .gnb_main .menu1 a:hover .ico{background:url(https://res.kurly.com/pc/service/common/1908/ico_gnb_all.png) no-repeat 0 0}
  #gnb .gnb_main .menu1 a.on .txt,
  #gnb .gnb_main .menu1 a:hover .txt,
  #gnb .gnb_main .menu1 .txt{float:left;font-weight:700;border-bottom:0}
  #gnb .gnb_main .menu3 a{width:116px}
  #gnb .gnb_main .lst a{width:116px}
  /* GNB���� */
  #gnb .gnb_sub{display:none;overflow:hidden;position:absolute;z-index:301;left:0;top:55px;width:213px;padding-top:1px}
  #gnb .gnb_sub .inner_sub{width:100%;border:1px solid #ddd;background:url(https://res.kurly.com/pc/service/common/1908/bg_gnb_sub_v3.png) repeat-y 0 0}
  #gnb .size_over{overflow-x:hidden;overflow-y:auto}
  #gnb .gnb_sub .gnb_menu{width:219px}
  #gnb .gnb_sub .gnb_menu li{width:100%;text-align:left}
  #gnb .gnb_sub .gnb_menu li:first-child{padding-top:0}
  #gnb .gnb_sub .menu{display:block;overflow:hidden;width:100%;height:40px;padding:8px 0 0 14px;cursor:pointer}
  #gnb .gnb_sub .gnb_menu li:first-child .menu{height:39px;padding-top:7px}
  #gnb .gnb_sub .current .menu{background:#f7f7f7}
  #gnb .gnb_sub .current .txt,
  #gnb .gnb_sub .menu.on.off:hover .txt,
  #gnb .gnb_sub .menu.on .txt{font-weight:700;color:#5f0080}
  #gnb .gnb_sub .ico{float:left;width:24px;height:24px}
  #gnb .gnb_sub .ico img{width:24px;height:24px}
  #gnb .gnb_sub .ico .ico_off{display:block}
  #gnb .gnb_sub .ico .ico_on{display:none}
  #gnb .gnb_sub .current .ico_off,
  #gnb .gnb_sub .menu.on .ico_off,
  #gnb .gnb_sub .menu:hover .ico_off{display:none}
  #gnb .gnb_sub .current .ico_on,
  #gnb .gnb_sub .menu.on .ico_on,
  #gnb .gnb_sub .menu:hover .ico_on{display:block}
  #gnb .gnb_sub .ico_arrow{display:none;float:right;width:16px;height:17px;padding:6px 9px 0 0}
  #gnb .gnb_sub .ico_arrow img{width:7px;height:11px}
  #gnb .gnb_sub .current .ico_arrow{display:block}
  #gnb .gnb_sub .txt{float:left;padding:0 4px 0 10px;font-weight:400;font-size:14px;color:#333;line-height:22px;white-space:nowrap}
  #gnb .gnb_sub .ico_new{overflow:hidden;float:left;width:14px;height:14px;margin-top:5px;background-position:50% 50%;background-repeat:no-repeat;background-size:14px 14px;font-size:0;line-height:0;text-indent:-9999px}
  #gnb .gnb_sub .sub_menu{position:absolute;z-index:0;left:200px;top:0;width:248px;height:100%;padding:0 0 0 20px;background:url(https://res.kurly.com/images/common/bg_1_1.gif) repeat 0 0;opacity:0;transition:opacity 0.2s}
  #gnb .gnb_sub .current .sub_menu{z-index:1;opacity:1;transition:opacity 0.5s}
  #gnb .gnb_sub .sub_menu li:first-child{padding-top:11px}
  #gnb .gnb_sub .sub_menu .sub{display:block;overflow:hidden;height:40px;padding-left:20px;font-size:14px;color:#333;line-height:18px;cursor:pointer}
  #gnb .gnb_sub .sub_menu .sub:hover .name{border-bottom:1px solid #5f0080;font-weight:700;color:#5f0080}
  #gnb .gnb_sub .sub_menu .sub.on{font-weight:700;color:#5f0080}
  #gnb .gnb_sub .recommend{overflow:hidden;width:529px;padding:21px 0 0 40px}
  #gnb .gnb_sub .recommend li{float:left;width:120px;height:130px;padding:0 10px 0 0}
  #gnb .gnb_sub .recommend li:first-child{padding-top:0}
  #gnb .gnb_sub .recommend .sub{display:block;overflow:hidden;width:120px;height:130px;padding:0;cursor:pointer}
  #gnb .gnb_sub .recommend .thumb{display:block;width:110px;height:83.4px;margin-bottom:8px;background-position:50% 50%;background-repeat:no-repeat;background-size:cover}
  #gnb .gnb_sub .recommend .thumb img{width:110px;height:84px}
  #gnb .gnb_sub .recommend .name{font-size:14px;line-height:18px}
  #gnb .btn_location{overflow:hidden;position:absolute;right:51px;top:10px;width:36px;height:36px;border:0 none;background:url(https://res.kurly.com/pc/ico/2008/ico_delivery_setting_done.svg) no-repeat 50% 50%;font-size:0;text-indent:-9999px}
  #gnb .btn_location.on{background-image:url(https://res.kurly.com/pc/ico/2008/ico_delivery_setting.svg?ver=1)}
  #gnb .layer_location{display:none;position:absolute;z-index:300;right:41px;top:56px;width:315px;padding:18px 18px 19px 20px;border:1px solid #ddd;background-color:#fff}
  #gnb .layer_location:after{content:"";position:absolute;right:10px;top:-50px;width:36px;height:50px;background:url(https://res.kurly.com/pc/ico/2011/ico_point_up_18x12.svg) no-repeat 50% 100%}
  #gnb .layer_location *{font-weight:700;font-size:16px;color:#333;line-height:24px;letter-spacing:-0.3px}
  #gnb .layer_location .delivery{display:block;padding-top:8px;font-size:14px;line-height:20px}
  #gnb .layer_location .star{color:#5f0080}
  #gnb .layer_location .regular{color:#666}
  #gnb .layer_location .none{color:#999}
  #gnb .layer_location .btn{display:block;width:100%;height:36px;margin-top:17px;padding-bottom:2px;border-radius:3px;font-size:12px;line-height:32px;letter-spacing:0;text-align:center}
  #gnb .layer_location a.btn{padding-top:0}
  #gnb .layer_location .btn.default{border:1px solid #5f0080;background-color:#fff;color:#5f0080}
  #gnb .layer_location .btn.active{border:1px solid #5f0081;background-color:#5f0080;color:#fff}
  #gnb .layer_location .btn .ico{display:inline-block;width:20px;height:20px;margin:6px 0 0 -6px;background:url(https://res.kurly.com/pc/ico/2008/ico_search_40x40.png) no-repeat 50% 50%;background-size:20px 20px;vertical-align:top}
  #gnb .layer_location .group_button{display:block;overflow:hidden}
  #gnb .layer_location .double .default{float:left;width:110px}
  #gnb .layer_location .double .active{float:right;width:159px}
  #gnb .layer_location .double .btn {margin-left: 0; margin-right:0;}
  #gnb .layer_location .emph{color:#5f0080}
  #gnb .location_set:hover .btn_location.on{background-image:url(https://res.kurly.com/pc/ico/2010/ico_delivery_setting_on.svg)}
  #gnb .location_set.show .layer_location,
  #gnb .location_set:hover .layer_location{display:block}
  #gnb .location_set .btn_location.off,
  #gnb .location_set .btn_location.off:hover{background-image:url(https://res.kurly.com/pc/ico/2008/ico_delivery_off.svg?ver=1);cursor:default}
  #gnb .location_set.off .layer_location,
  #gnb .location_set.off:hover .layer_location{display:none}
  /* ���� */
  #gnb .layer_location .error .txt{display:block;color:#333}
  @media
  only screen and (-webkit-min-device-pixel-ratio: 1.5),
  only screen and (min-device-pixel-ratio: 1.5),
  only screen and (min-resolution: 1.5dppx) {
    #gnb .gnb_sub .ico_new{background:url(https://res.kurly.com/pc/ico/1808/ico_new_gnb_16x16.png) no-repeat 0 0;background-size:14px 14px}
    #gnb .cart_count .msg_cart .point{background:url(https://res.kurly.com/pc/ico/1903/ico_layer_point_x2.png) no-repeat 0 0;background-size:20px 14px}
    #gnb .gnb_main .menu1 .ico{background:url(https://res.kurly.com/pc/service/common/1908/ico_gnb_all_off_x2.png) no-repeat 0 0;background-size:16px 14px}
    #gnb .gnb_main .menu1 a.on .ico,
    #gnb .gnb_main .menu1 a:hover .ico{background:url(https://res.kurly.com/pc/service/common/1908/ico_gnb_all_x2.png) no-repeat 0 0;background-size:16px 14px}
  }
  .gnb_search .init{position:relative}
  .gnb_search .init .btn_delete{overflow:hidden;position:absolute;left:170px;top:-36px;width:36px;height:36px;border:0 none;background:url(https://res.kurly.com/pc/ico/2010/ico_search_del.svg) no-repeat 50% 50%;background-size:12px 12px;font-size:0;line-height:0;text-indent:-9999px;opacity:0}
  .gnb_search .init .btn_delete.on{opacity:1}
</style>
<div id="headerLogo" class="layout-wrapper">
<h1 class="logo">
<a href="/" class="link_main">
<span id="gnbLogoContainer"></span>
<img src="https://res.kurly.com/images/marketkurly/logo/logo_x2.png" alt="�����ø� �ΰ�">
</a>
</h1>
<a href="/shop/board/view.php?id=notice&no=64" onclick="ga('send','event','etc','main_gif_btn_click');" class="bnr_delivery">
<img src="https://res.kurly.com/pc/service/common/2011/delivery_210801.png" alt="����, �ù� ��۾ȳ�" width="121" height="22">
</a>
</div>
<div id="gnb">
<h2 class="screen_out">�޴�</h2>
<div id="gnbMenu" class="gnb_kurly">
<div class="inner_gnbkurly">
<div class="gnb_main">
<ul class="gnb">
<li class="menu1"><a href="#none"><span class="ico"></span><span class="txt">��ü ī�װ���</span></a></li>
<li class="menu2"><a class="link new " href="/shop/goods/goods_list.php?category=038"><span class="txt">�Ż�ǰ</span></a></li>
<li class="menu3"><a class="link best " href="/shop/goods/goods_list.php?category=029"><span class="txt">����Ʈ</span></a></li>
<li class="menu4"><a class="link bargain " href="/shop/goods/goods_list.php?list=sale"><span class="txt">�˶����</span></a></li>
<li class="lst"><a class="link event " href="/shop/goods/event.php?&"><span class="txt">Ư��/����</span></a></li>
</ul>
<div id="side_search" class="gnb_search">
<form action="/shop/goods/goods_search.php?&" onsubmit="return searchTracking(this)">
<input type=hidden name=searched value="Y">
<input type=hidden name=log value="1">
<input type=hidden name=skey value="all">
<input type="hidden" name="hid_pr_text" value="">
<input type="hidden" name="hid_link_url" value="">
<input type="hidden" id="edit" name="edit" value="">
<input name="sword" type="text" id="sword" class="inp_search" value="" required label="�˻���" placeholder="�˻�� �Է����ּ���.">
<input type=image src="https://res.kurly.com/pc/service/common/1908/ico_search_x2.png" class="btn_search">
<div class="init">
<button type="button" class="btn_delete" id="searchInit">�˻��� �����ϱ�</button>
</div>
</form>
<script>
            // KM-1483 Amplitude ����
            function searchTracking(form){
              var searchCharacter = $(form).find('[name = sword]').val();
              searchCharacter = searchCharacter.replace(/\"/gi, "");
              var _searchTrackingData = {
                selection_type : 'keyword',
                keyword : searchCharacter,
                package_id : null,
                package_name : null,
                position : null,
              }
              KurlyTracker.setEventInfo(_searchTrackingData.selection_type);
              KurlyTracker.setAction('select_search', _searchTrackingData).sendData();
              return chkForm(form);
            }
          </script>
</div>
<div class="cart_count">
<div class="inner_cartcount">
<a href="/shop/goods/goods_cart.php" class="btn_cart">
<span class="screen_out">��ٱ���</span>
<span class="num realtime_cartcount" id="cart_item_count"></span> </a>
</div>
<div id="addMsgCart" class="msg_cart">
<span class="point"></span>
<div class="inner_msgcart">
<img src="https://res.kurly.com/images/common/bg_1_1.gif" alt="" class="thumb">
<p id="msgReaddedItem" class="desc">
<span class="tit"></span>
<span class="txt">
��ٱ��Ͽ� ��ǰ�� ��ҽ��ϴ�.
<span class="repeat">�̹� ������ ��ǰ�� �־� �߰��Ǿ����ϴ�.</span>
</span>
</p>
</div>
</div>
</div>
<div class="location_set">
<button type="button" class="btn_location on">����� �����ϱ�</button>
<div class="layer_location" style="display:none"></div>
</div>
<script src="/asset/js/myp/destination/popup.bundle.js?ver=1.38.2"></script>
</div>
<div class="gnb_sub">
<div class="inner_sub">
<ul class="gnb_menu" data-default="219" data-min="219" data-max="731">
<gnb-menu-pc v-for="(item, idx) in dataGnb" :main-menu="item" :sub-menu="item.categories" :sub-open="item.subOpen" :get-category-num="getCategoryNum" :key="'gnb'+idx" :idx="idx"></gnb-menu-pc>
</ul>
</div>
</div>
</div>
</div>
</div>
<script src="/common_js/gnb_v1.js?ver=1.38.2"></script>
<script type="text/javascript">
  //
  gnbMenu.update();

  // �˻�â Ŭ���� �߰�/����
  var searchInputAction = (function(){
    var $target = {};

    var _searchInputAction = {
      setSeletor: function(){
        $target = {
          $parent: $('#gnb'),
          $search: $('#gnb [name=sword]'),
          $deleteBtn: $('#searchInit'),
          $edit: $('#edit')
        }

        this.setAction();
      },
      setAction: function(){
        var that = this;
        $target.$search.focus(function(){
          that.changeClass($target.$search, 'add', 'focus');
          that.deleteCheck();
        }).blur(function(){
          that.changeClass($target.$search, 'remove', 'focus');
          that.deleteCheck(false);
        }).on('keyup', function(){
          if($target.$edit.val() !== 'Y'){
            $target.$edit.val('Y');
          }
          that.deleteCheck();
        });

        $target.$deleteBtn.on('click', function(){
          $target.$search.val('');
          that.deleteCheck();
        });
      },
      deleteCheck: function(type){
        var that = this, count = $.trim($target.$search.val()).length;
        if(count === 0 || (typeof type !== 'undefined' &&  !type) ){
          that.changeClass($target.$deleteBtn, 'remove', 'on');
        }else{
          that.changeClass($target.$deleteBtn, 'add', 'on');
        }
      },
      changeClass: function(target, type, className){
        if(type === 'add'){
          target.addClass(className);
        }else{
          target.removeClass(className);
        }
      }
    }

    _searchInputAction.setSeletor();
  })();

  // �ΰ� Ŭ�� �̺�Ʈ
  $('#header .link_main').on('click', function(e){
    e.preventDefault();
    var url = $(this).attr('href');
    if (url.indexOf('/') === 0) {
      url = window.location.origin + url;
    }

    KurlyTracker.setAction('select_main_logo', {"url": url}).sendData();
    location.href = url;
  });

  $('#gnb .gnb .link').on('click', function(e){
    e.preventDefault();
    var _event_name, _event_info;
    if($(this).hasClass('new')){
      _event_name = 'select_new_product_subtab';
    }else if($(this).hasClass('best')){
      _event_name = 'select_popular_product_subtab';
    }else if($(this).hasClass('bargain')){
      _event_name = 'select_bargain_subtab';
    }else if($(this).hasClass('event')){
      _event_name = 'select_event_list_subtab';
    }
    _event_info = $(this).attr('href');

    KurlyTracker.setEventInfo(_event_info).setAction(_event_name).sendData();
    location.href = _event_info;
  });

  // ��ٱ��� ������ Ŭ���̺�Ʈ
  $('#gnbMenu .btn_cart').on('click', function(e){
    e.preventDefault();
    KurlyTracker.setAction('select_cart').sendData();
    location.href = $(this).attr('href');
  });
</script>
</div>
<div id="main">
<div id="content">

<div id="qnb" class="quick-navigation">
<style>
    #qnb{position:absolute;z-index:1;right:20px;top:70px;width:80px;font:normal 12px/16px "Noto Sans";color:#333;letter-spacing:-0.3px;transition:top 0.2s}
    .goods-goods_view #qnb{top:20px}
    /* ��� */
    #qnb .bnr_qnb{padding-bottom:7px}
    #qnb .bnr_qnb .thumb{width:80px;height:120px;vertical-align:top}
    /* �޴� */    
    #qnb .side_menu{width:80px;border:1px solid #ddd;border-top:0 none;background-color:#fff}
    #qnb .link_menu{display:block;height:29px;padding-top:5px;border-top:1px solid #ddd;text-align:center}
    #qnb .link_menu:hover,
    #qnb .link_menu.on{color:#5f0080}
    /* �ֱٺ���ǰ */
    #qnb .side_recent{position:relative;margin-top:6px;border:1px solid #ddd;background-color:#fff}
    #qnb .side_recent .tit{display:block;padding:22px 0 6px;text-align:center}
    #qnb .side_recent .list_goods{overflow:hidden;position:relative;width:60px;margin:0 auto}
    #qnb .side_recent .list{position:absolute;left:0;top:0}
    #qnb .side_recent .link_goods{display:block;overflow:hidden;width:60px;height:80px;padding:1px 0 2px}
    #qnb .side_recent .btn{display:block;overflow:hidden;width:100%;height:17px;border:0 none;font-size:0;line-height:0;text-indent:-9999px}
    
    #qnb .side_recent .btn_up{position:absolute;left:0;top:0;background:url(https://res.kurly.com/pc/service/main/2002/ico_quick_up_hover.png) no-repeat 50% 50%}
    #qnb .side_recent .btn_up.off{background:url(https://res.kurly.com/pc/service/main/2002/ico_quick_up.png) no-repeat 50% 50%}
    #qnb .side_recent .btn_down{background:url(https://res.kurly.com/pc/service/main/2002/ico_quick_down_hover.png) no-repeat 50% 0}
    #qnb .side_recent .btn_down.off{background:url(https://res.kurly.com/pc/service/main/2002/ico_quick_down.png) no-repeat 50% 0}
    
    
    @media
    only screen and (-webkit-min-device-pixel-ratio: 1.5),
    only screen and (min-device-pixel-ratio: 1.5),
    only screen and (min-resolution: 1.5dppx) {
        #qnb .side_recent .btn_up{background-image:url(https://res.kurly.com/pc/service/main/2002/ico_quick_up_hover_x2.png);background-size:12px 18px}
        #qnb .side_recent .btn_down{background-image:url(https://res.kurly.com/pc/service/main/2002/ico_quick_down_hover_x2.png);background-size:12px 18px}
        #qnb .side_recent .btn_up.off{background-image:url(https://res.kurly.com/pc/service/main/2002/ico_quick_up_x2.png);background-size:12px 18px}
        #qnb .side_recent .btn_down.off{background-image:url(https://res.kurly.com/pc/service/main/2002/ico_quick_down_x2.png);background-size:12px 18px}
    }
    @media all and (max-width: 1250px){
        #qnb{display:none}
    }
</style>

<div class="bnr_qnb" id="brnQuick"></div>
<script>
    var brnQuick = {
        nowTime : '1629958124592',
        update : function(){
            $.ajax({
                url : campaginUrl + 'pc/service/bnr_quick.html'
            }).done(function(result){
                $('#brnQuick').html(result);
            });    
        }
    }
    brnQuick.update();
</script>

<div class="side_menu">
<a href="/shop/main/html.php?htmid=event/kurly.htm&name=lovers" class="link_menu ">��޺� ����</a>
<a href="/shop/board/list.php?id=recipe" class="link_menu ">������</a>
<a href="/shop/goods/goods_review_best.php" class="link_menu ">����Ʈ �ı�</a>
</div>
<div class="side_recent" style="display:none">
<strong class="tit">�ֱ� �� ��ǰ</strong>
<div class="list_goods" data-height="209">
<ul class="list"></ul>
</div>
<button type="button" class="btn btn_up off">�ֱ� �� ��ǰ ���� �ø���</button>
<button type="button" class="btn btn_down">�ֱ� �� ��ǰ �Ʒ��� ������</button>
</div>
<script>
/**
 * ��ǰ���϶� ���� ���� �ִ� ��ǰ ���. ��ǰURL & ��ǰ�̹���
 * ���� ���� ��¥�� ���� 24�ð� ������ localStorage ����
 */
var getGoodsRecent = (function(){
    var i, len, getGoodsRecent, item, _nowTime = '1629958124592';

    _goodsRecent();
    function _goodsRecent(){
        if(localStorage.getItem('goodsRecent') === null){
            return false;
        }
        
        try{
            getGoodsRecent = JSON.parse(localStorage.getItem("goodsRecent"));
            len = getGoodsRecent.length;
            if(addDays(getGoodsRecent[len - 1].time, 1) < _nowTime){
                localStorage.removeItem('goodsRecent');
            }else{
                for(i = 0; i < len; i++){
                    item = '<li><a class="link_goods" href="/shop/goods/goods_view.php?goodsno=' + getGoodsRecent[i].no + '"><img src="' + getGoodsRecent[i].thumb + '" alt=""></a></li>';
                    $('.side_recent .list').append(item);
                }
                $('.side_recent').show();
            }
        } catch(e){
            console.log("JSON parse error from the Quick menu goods list!!!", e);
        }
    }

    function addDays(date, days){
        var result = new Date(date);
        result.setDate(result.getDate() + days);
        return result.getTime();
    }
    
    // return {
    // }
})();
</script>
</div>
<style>
    /* override */
    #content{padding-bottom:0}
    #qnb{top:516px}
    #headerLogo .logo img {display: none}


    /* ############## */
    /* ���� ���� �˾� */
    /* ############## */
    #mainNotice{position:relative;z-index:5000;width:1050px;margin:0 auto}
    #mainNotice .main_popup{overflow:hidden;position:absolute;left:0;top:40px;width:440px;border-radius:6px;background-color:#f4f4f4;
        -webkit-box-shadow:0 1px 8px 0 rgba(0, 0, 0, 0.2);
        -moz-box-shadow:0 1px 8px 0 rgba(0, 0, 0, 0.2);
        box-shadow:0 1px 8px 0 rgba(0, 0, 0, 0.2);
    }
    #mainNotice .main_popup1{left:0}
    #mainNotice .main_popup2{left:0}
    #mainNotice .main_popup3{left:0}
    #mainNotice .main_popup4{left:0}
    #mainNotice .inner_mainpopup{position:relative;height:100%}
    #mainNotice .pop_view img{width:100%;vertical-align:top}
    /* �ϴܹ�ư */
    #mainNotice .pop_footer{overflow:hidden;width:100%;height:60px;border-top:1px solid #f7f7f7;background-color:#fff}
    #mainNotice .pop_footer .btn{overflow:hidden;float:left;width:100%;height:100%;border:0 none;background-color:#fff;font-family:'Noto Sans';font-weight:400;font-size:16px;color:#333;line-height:20px;text-align:center}
    #mainNotice .pop_select .btn{float:left;width:219px;}
    #mainNotice .pop_select .btn:last-child{float:right;width:219px;border-left:1px solid #f7f7f7}
    /* ��й�ȣ���� �˾� */
    #change_pw{position:absolute;left:0;top:0;width:404px}
    #change_pw .inner_popdiv{width:404px;padding:0 20px;background-color:#fff;border:2px solid #514859;text-align:left}
    #change_pw .line{height: 2px;border:none; outline: none;  background-color:#5f0080}
    #change_pw .line_grey{height: 2px;border:none; outline: none;background-color:#dddfe1}
    #change_pw .tit{display:block;padding:32px 0 15px;font-size:16px;font-weight:700;color:#5f0080}
    #change_pw .wrap_pw{padding:22px 0;font-size:16px;color:#000}
    #change_pw .desc{padding-bottom:10px;letter-spacing:-.5px}
    #change_pw .btn_group{height:50px}
    #change_pw .inner_popdiv .btn{overflow:hidden;position:absolute;bottom:2px;height:26px;font-size:14px;line-height:26px}
    #change_pw .inner_popdiv .btn_close { left:2px; width:200px; background-color:#fff; color:#5f0080; border-top:1px solid #5f0080; height:50px; text-align:center; line-height:50px; font-size:16px; letter-spacing:0.5px}
    #change_pw .inner_popdiv .link_move{right:2px;width:200px;background-color:#5f0080;color:#fff;border:1px solid #512771; height:50px; text-align:center; line-height:50px; font-size:16px; letter-spacing:0.5px}
    #change_pw .inp_tit{display:block;padding:13px 0 5px 0;font-size:14px;letter-spacing:-.5px; color:#5f0080;font-weight:bold}
    #change_pw .wrap_inp{position:relative}
    #change_pw .txt_placeholder {position:absolute; z-index:9; display:block; font-size:16px; top:12px; left:10px;font-family:"Noto Sans";font-weight:200;line-height:18px; color:#949296}
    #change_pw .pw_inp{width:100%;padding:10px}
    #change_pw .item_info dt{padding-bottom:5px}
    #change_pw .pw_notice{padding-top:19px}
    #change_pw .new_pw{margin-bottom:20px}
    #change_pw .mark_valid{ display:none;font-size:12px;color:#514859;line-height:20px}
    #change_pw .wrap_inp .mark_valid .good{ color:#0e851a }
    #change_pw .wrap_inp .mark_valid .bad{ color:#b3130b }
    #change_pw .wrap_inp .mark_coincide.good{ color:#0e851a }
    #change_pw .wrap_inp .mark_coincide.bad{ color:#b3130b }
    #change_pw .pw_inp.inp_invalid{border: 1px solid #b3130b}
    #change_pw input[type=password]{height:44px; outline: none; border: 1px solid #514859}

    /* #### */
    /* ���� */
    /* #### */
    .page_main{overflow:hidden;width:100%;margin:0;opacity:0}
    .page_main *{color:#333}
    .page_main .bg{background-color:#f7f7f7}
    .page_main .tit_goods{padding:79px 0 35px}
    .page_main .tit_goods.top_short{padding-top:21px}
    .page_main .tit_goods .tit{font-weight:700;font-size:28px;line-height:32px;letter-spacing:-0.3px;text-align:center}
    .page_main .tit_goods .name{position:relative;font-weight:700}
    .page_main .tit_goods a{cursor:pointer}
    .page_main .tit_goods .name .ico{padding:0 31px;background:url(https://res.kurly.com/pc/service/main/1908/ico_title_link_x1.png) no-repeat 100% 50%;font-weight:700}
    .page_main .tit_goods .tit_desc{display:block;padding-top:10px;font-weight:400;font-size:16px;color:#999;line-height:20px;text-align:center}
    .page_main .list_goods a{cursor:pointer}
    .page_main .list_goods .thumb_goods{display:block;overflow:hidden}
    .page_main .list_goods .thumb_goods .ico{z-index:1;transition:all 0.3s ease-in-out}
    .page_main .list_goods .thumb_goods .thumb{display:block;margin:0 auto;background-position:50% 50%;background-size:cover;transform:scale(1);transition:all 0.3s ease-in-out}
    .page_main .list_goods .thumb_goods:hover .thumb{transform:scale(1.02);transition:all 0.3s ease-in-out}

    /* �����̵�_��ư */
    .page_main .bx-controls-direction{position:relative;width:1050px;margin:0 auto}
    .page_main .bx-controls-direction .bx-next,
    .page_main .bx-controls-direction .bx-prev{overflow:hidden;position:absolute;bottom:316px;width:60px;height:60px;border:0 none;font-size:0;line-height:0;text-indent:-9999px;transition:opacity 0.5s}
    .page_main .bx-controls-direction .bx-prev{left:-30px;background:url(https://res.kurly.com/pc/service/main/1908/btn_prev_default.png?v=1) no-repeat 50% 50%;transition:background 0.5s}
    .page_main .bx-controls-direction .bx-prev:hover{background:url(https://res.kurly.com/pc/service/main/1908/btn_prev_default_hover_x1.png?v=1) no-repeat 50% 50%;transition:background 0.5s}
    .page_main .bx-controls-direction .bx-next{right:-30px;background:url(https://res.kurly.com/pc/service/main/1908/btn_next_default.png?v=1) no-repeat 50% 50%;transition:background 0.5s}
    .page_main .bx-controls-direction .bx-next:hover{background:url(https://res.kurly.com/pc/service/main/1908/btn_next_default_hover_x1.png?v=1) no-repeat 50% 50%;transition:background 0.5s}
    .page_main .bg .bx-controls-direction .bx-prev{left:-30px;background:url(https://res.kurly.com/pc/service/main/1908/btn_prev_gray_x1.png?v=1) no-repeat 50% 50%;transition:background 0.5s}
    .page_main .bg .bx-controls-direction .bx-prev:hover{background:url(https://res.kurly.com/pc/service/main/1908/btn_prev_gray_hover_x1.png?v=1) no-repeat 50% 50%;transition:background 0.5s}
    .page_main .bg .bx-controls-direction .bx-next{right:-30px;background:url(https://res.kurly.com/pc/service/main/1908/btn_next_gray_x1.png?v=1) no-repeat 50% 50%;transition:background 0.5s}
    .page_main .bg .bx-controls-direction .bx-next:hover{background:url(https://res.kurly.com/pc/service/main/1908/btn_next_gray_hover_x1.png?v=1) no-repeat 50% 50%;transition:background 0.5s}
    .page_main .bx-controls-direction .disabled{opacity:0}

    /* ####### */
    /* 1������ */
    /* ####### */
    /* 1������+�����̵�+fullsize */
    .main_type1 .list_goods .thumb_goods{width:100%;height:370px;background-repeat:no-repeat;background-position:50% 50%;background-size:auto auto;font-size:0;line-height:0;text-indent:-9999px}
    .main_type1 .bx-controls-auto{overflow:hidden;font-size:0;line-height:0;text-indent:-9999px}
    .main_type1 .bx-controls-direction .bx-next,
    .main_type1 .bx-controls-direction .bx-prev{bottom:159px;width:52px;height:52px;opacity:0}
    .main_type1 .bx-controls-direction .bx-prev:hover,
    .main_type1 .bx-controls-direction .bx-prev{left:-91px;background:url(https://res.kurly.com/pc/service/main/1908/ico_prev1_x1.png) no-repeat 50% 50%;transition:opacity 0.5s}
    .main_type1 .bx-controls-direction .bx-next:hover,
    .main_type1 .bx-controls-direction .bx-next{right:-91px;background:url(https://res.kurly.com/pc/service/main/1908/ico_next1_x1.png) no-repeat 50% 50%;transition:opacity 0.5s}
    .main_type1 .list_goods:hover .bx-next,
    .main_type1 .list_goods:hover .bx-prev{opacity:1}
    @media all and (max-width: 1250px){
        .main_type1 .bx-controls-direction .bx-prev:hover,
        .main_type1 .bx-controls-direction .bx-prev{left:-26px}
        .main_type1 .bx-controls-direction .bx-next:hover,
        .main_type1 .bx-controls-direction .bx-next{right:-26px}
    }

    /* ####### */
    /* 4������ */
    /* ####### */
    /* 4������+�����̵� */
    .main_type2 .global_sticker .inner_sticker{left:0;top:0}
    .main_type2 .list_goods{width:1050px;height:506px;margin:0 auto}
    .main_type2 .list_goods .list{width:99999px}
    .main_type2 .list_goods li{float:left;width:249px;height:506px;margin-right:18px}
    .main_type2 .list_goods .thumb_goods{position:relative;background-color:#eee}
    .main_type2 .list_goods .ico{position:absolute;left:0;top:0;width:62px;height:54px}
    .main_type2 .list_goods .thumb{width:249px;height:320px}
    .main_type2 .list_goods .name{display:block;overflow:hidden;max-height:50px;margin-top:12px;
        text-overflow:ellipsis;display: -webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;word-wrap:break-word
    }
    .main_type2 .list_goods .txt{font-size:16px;line-height:23px}
    .main_type2 .list_goods .price{display:block;padding-top:9px;font-weight:800;font-size:16px;line-height:20px}
    .main_type2 .list_goods .dc{padding-right:8px;font-weight:800;font-size:16px;color:#fa622f;line-height:20px}
    .main_type2 .list_goods .cost{display:block;padding-top:5px;font-size:14px;color:#999;line-height:18px;text-decoration:line-through}
    /* ������ ��õ */
    .category_type{padding-bottom:100px}
    .category_type .list_goods{height:462px}
    .category_type .list_goods.none{height:0}
    .category_type .list_goods li{height:462px}
    .category_type .bx-controls-direction .bx-next,
    .category_type .bx-controls-direction .bx-prev{bottom:272px}
    .category_type .category .list_category{width:1050px;max-width:1050px;padding:0 0 20px;margin:0 auto;text-align:center;font-size:0}
    .category_type .category .list_category li{display:inline-block;padding:0 5px 20px}
    .category_type .category .list_category .cut:before{content:"";display:block;overflow:hidden;width:100%;height:0}
    .category_type .category .list_category .menu{display:inline-block;height:40px;padding:9px 20px 0 19px;border:1px solid #f7f7f6;border-radius:20px;background-color:#f7f7f7;font-size:14px;line-height:18px}
    .category_type .category .list_category .menu:hover{border:1px solid #f7f3f7;background-color:#f7f3f8;color:#5f0080}
    .category_type .category .list_category .on:hover,
    .category_type .category .list_category .on{border:1px solid #5f0081;background-color:#5f0080;font-weight:700;color:#fff}
    .category_type .link_cate{width:516px;margin:0 auto}
    .category_type .link_cate .link{display:block;overflow:hidden;height:56px;padding-top:16px;border:1px solid #e3e3e3;border-radius:3px;font-size:16px;line-height:20px;text-align:center;letter-spacing:-0.3px;cursor:pointer}
    .category_type .link_cate .ico{padding:0 18px;background:url(https://res.kurly.com/pc/service/main/1903/ico_more_link_x1.png) no-repeat 100% 3px}
    .category_type .min .bx-controls{opacity:0}
    .category_type .list_goods.over{overflow:hidden}
    .category_type .list_goods.over .bx-controls{opacity:0}

    /* ####### */
    /* 3������ */
    /* ####### */
    .main_type3 .list_goods{width:1050px;margin:0 auto}
    .main_type3 .list_goods .list{width:99999px}
    .main_type3 .list_goods li{float:left;width:338px;margin-right:18px}
    .main_type3 .list_goods .thumb_goods{display:block;position:relative}
    .main_type3 .list_goods .ico{position:absolute;left:0;top:0;width:62px;height:54px}
    .main_type3 .list_goods .thumb{width:338px}
    .main_type3 .list_goods .name{display:block;overflow:hidden}
    .main_type3 .list_goods .desc{display:block;overflow:hidden;text-align:center;white-space:nowrap;text-overflow:ellipsis}
    .main_type3 .list_goods .desc .txt{font-size:16px;line-height:20px}
    /* 3������_�̺�Ʈ */
    .main_event .list_goods{overflow:hidden;height:538px}
    .main_event .list_goods .list{width:1068px}
    .main_event .list_goods li{height:538px}
    .main_event .list_goods .thumb{height:338px}
    .main_event .list_goods .name{max-height:54px;margin-top:17px;text-align:center;
        text-overflow:ellipsis;display: -webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;word-wrap:break-word
    }
    .main_event .list_goods .name .txt{font-weight:700;font-size:18px;line-height:28px;letter-spacing:-0.3px}
    .main_event .list_goods .desc{padding-top:8px}
    .main_event .list_goods .desc .txt{color:#999}
    .main_event.min .list_goods{text-align:center}
    .main_event.min .list_goods .list{display:inline-block;width:auto;padding-left:18px}
    /* 3������_������ */
    .main_recipe .list_goods{height:303px}
    .main_recipe .list_goods li{height:303px}
    .main_recipe .list_goods .thumb{height:225px}
    .main_recipe .list_goods .name{padding-top:12px;text-align:center;white-space:nowrap;text-overflow:ellipsis}
    .main_recipe .list_goods .txt{font-size:16px;line-height:20px}
    .main_recipe .bx-controls-direction .bx-next,
    .main_recipe .bx-controls-direction .bx-prev{bottom:160px}

    /* ####### */
    /* 6������ */
    /* ####### */
    /* 6������+�����̵� : �ν�Ÿ�׷����� */
    .main_type4 .list_goods{width:1050px;height:175px;margin:0 auto}
    .main_type4 .list_goods .list{width:99999px}
    .main_type4 .list_goods li{float:left;width:175px;height:175px}
    .main_type4 .list_goods .thumb{width:175px;height:175px}
    .main_type4 .list_goods .thumb_goods:hover .thumb{transform:scale(1)}
    .main_type4 .bnr{padding:39px 0 100px;font-weight:700;font-size:16px;line-height:29px;text-align:center}
    .main_type4 .bnr .txt{display:block;font-weight:400;color:#999}
    .main_type4 .bnr a{font-weight:700}
    .main_type4 .bx-controls-direction .bx-next,
    .main_type4 .bx-controls-direction .bx-prev{bottom:58px}
    .main_type4 .bx-controls-auto{overflow:hidden;font-size:0;line-height:0;text-indent:-9999px}

    /* ######## */
    /* ����ȵ� */
    /* ######## */
    .main_special{padding-bottom:88px}
    .main_special .inner_special{overflow:hidden;width:1050px;margin:0 auto;padding-top:20px}
    .main_special .inner_special.no_line{border-top:0 none}
    .main_special .tit_goods{float:left;width:338px;padding:11px 0 7px 10px}
    .main_special .tit_goods .tit{height:173px;padding-left:2px;text-align:left}
    .main_special .tit_goods .name{font-weight:700;font-size:32px;line-height:48px}
    .main_special .tit_goods .tit_desc:before{content:"";display:block;width:12px;height:1px;margin:7px 0 16px 2px;background-color:#999;word-break:break-all}
    .main_special .tit_goods .tit_desc{font-size:16px;line-height:24px;letter-spacing:0;text-align:left;}
    .main_special .sub_hook{padding:0 0 10px 22px;background:url(https://res.kurly.com/pc/service/main/2010/ico_hook.svg) no-repeat 0 2px;background-size:18px 18px;font-size:14px;color:#ccc;line-height:20px;letter-spacing:-0.4px}
    .main_special .list_goods{float:right;width:694px}
    .main_special .list_goods .list{overflow:hidden;width:712px}
    .main_special .list_goods li{width:694px}
    .main_special .list_goods .thumb_goods{position:relative;background-color:#eee}
    .main_special .list_goods .thumb{display:block;width:694px;height:338px;}
    .main_special .list_goods .ico{position:absolute;left:0;top:0;width:62px;}
    .main_special .list_goods .bg{position:absolute;left:0;bottom:0;width:100%;height:40px;opacity:0.6}
    .main_special .list_goods .count{position:absolute;left:0;bottom:8px;width:100%;text-align:center}
    .main_special .list_goods .count .num{font-weight:bold;font-size:20px;color:#fff;line-height:24px}
    .main_special .list_goods .count .txt{font-size:14px;color:#fff;line-height:24px;vertical-align:2px}
    .main_special .list_goods .info_goods{position:relative}
    .main_special .list_goods .name{display:block;overflow:hidden;width:100%;padding:13px 0 0 4px;white-space:nowrap;text-overflow:ellipsis}
    .main_special .list_goods .name .txt{font-size:16px;line-height:24px}
    .main_special .list_goods .sub_name{display:block;overflow:hidden;width:100%;padding:5px 0 7px 4px;font-size:16px;color:#999;line-height:20px;white-space:nowrap;text-overflow:ellipsis}
    .main_special .list_goods .price{overflow:hidden;padding-left:4px}
    .main_special .list_goods .dc{float:left;padding-right:6px;font-weight:800;font-size:20px;color:#fa622f;line-height:30px}
    .main_special .list_goods .in_price{float:left;}
    .main_special .list_goods .selling{font-weight:800;font-size:20px;line-height:30px}
    .main_special .list_goods .cost{padding-left:4px;font-size:14px;color:#999;line-height:30px;text-decoration:line-through}
    /* sold_out */
    .main_special .list_goods .sold_out .bg{z-index:2;height:100%;background-color:#000;opacity:0.5}
    .main_special .list_goods .sold_out .info{position:absolute;z-index:2;left:0;top:50%;width:100%;margin-top:-2px;transform:translate(0, -50%);text-align:center}
    .main_special .list_goods .sold_out .tit{display:block;font-weight:bold;font-size:28px;color:#fff;line-height:40px}
    .main_special .list_goods .sold_out .desc{display:block;padding:11px 10px 0;font-size:16px;color:#fff;line-height:24px;word-break:break-all}
    /* 2���϶� */
    .main_special .list_goods2 li{float:left;width:338px;margin-right:18px;padding-bottom:3px}
    .main_special .list_goods2 .thumb{width:338px;height:434px}
    .main_special .list_goods2 .name{max-height:66px;padding-top:14px;white-space:normal;
        display: -webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;word-wrap:break-word
    }
    .main_special .list_goods2 .sub_name{display:none;padding:0}

    /* #### */
    /* ��� */
    /* #### */
    .bnr_main{width:1050px;margin:0 auto}
    .bnr_main .link{display:block;min-height:140px;background-color:#eee;background-position:50% 50%;background-size:cover;cursor:pointer}
    .bnr_main .tit{display:block;overflow:hidden;width:100%;padding:35px 50px 0;font-weight:700;font-size:28px;line-height:38px;white-space:nowrap;text-overflow:ellipsis}
    .bnr_main .txt{display:block;overflow:hidden;width:100%;padding:5px 50px 0;font-size:16px;line-height:24px;white-space:nowrap;text-overflow:ellipsis}
    .bnr_type2 .link{height:160px;padding-top:24px}
    .bnr_type2 .tit{line-height:40px}
    .bnr_type2 .txt{padding-top:7px}

    @media
    only screen and (-webkit-min-device-pixel-ratio: 1.5),
    only screen and (min-device-pixel-ratio: 1.5),
    only screen and (min-resolution: 1.5dppx) {
        .page_main .bx-controls-direction .bx-prev{background:url(https://res.kurly.com/pc/service/main/1908/btn_prev_default_x2.png?v=1) no-repeat 50% 50%;background-size:60px 60px}
        .page_main .bx-controls-direction .bx-prev:hover{background:url(https://res.kurly.com/pc/service/main/1908/btn_prev_default_hover_x2.png?v=1) no-repeat 50% 50%;background-size:60px 60px}
        .page_main .bx-controls-direction .bx-next{background:url(https://res.kurly.com/pc/service/main/1908/btn_next_default_x2.png?v=1) no-repeat 50% 50%;background-size:60px 60px}
        .page_main .bx-controls-direction .bx-next:hover{background:url(https://res.kurly.com/pc/service/main/1908/btn_next_default_hover_x2.png?v=1) no-repeat 50% 50%;background-size:60px 60px}
        .page_main .bg .bx-controls-direction .bx-prev{background:url(https://res.kurly.com/pc/service/main/1908/btn_prev_gray_x2.png?v=1) no-repeat 50% 50%;background-size:60px 60px}
        .page_main .bg .bx-controls-direction .bx-prev:hover{background:url(https://res.kurly.com/pc/service/main/1908/btn_prev_gray_hover_x2.png?v=1) no-repeat 50% 50%;background-size:60px 60px}
        .page_main .bg .bx-controls-direction .bx-next{background:url(https://res.kurly.com/pc/service/main/1908/btn_next_gray_x2.png?v=1) no-repeat 50% 50%;background-size:60px 60px}
        .page_main .bg .bx-controls-direction .bx-next:hover{background:url(https://res.kurly.com/pc/service/main/1908/btn_next_gray_hover_x2.png?v=1) no-repeat 50% 50%;background-size:60px 60px}
        .page_main .tit_goods .name .ico{background:url(https://res.kurly.com/pc/service/main/1908/ico_title_link_x2.png) no-repeat 100% 50%;background-size:32px 32px}
        .main_type1 .bx-controls-direction .bx-prev:hover,
        .main_type1 .bx-controls-direction .bx-prev{background:url(https://res.kurly.com/pc/service/main/1908/ico_prev1_x2.png) no-repeat 50% 50%;background-size:52px 52px}
        .main_type1 .bx-controls-direction .bx-next:hover,
        .main_type1 .bx-controls-direction .bx-next{background:url(https://res.kurly.com/pc/service/main/1908/ico_next1_x2.png) no-repeat 50% 50%;background-size:52px 52px}
        .main_md .link_more .ico{background:url(https://res.kurly.com/pc/service/main/1903/ico_more_link_x2.png) no-repeat 100% 50%;background-size:20px 20px}
        .category_type .link_more .ico{background-image:url(https://res.kurly.com/pc/service/main/1903/ico_more_link_x2.png);background-size:20px 20px}
    }

    #footer{opacity:0}

    .shell_ani {
      -webkit-animation-play-state: running;
      -moz-animation-play-state: running;
      -o-animation-play-state: running;
      animation-play-state: running;
      -moz-transform: translate3d(0, 0, 0);
      -ms-transform: translate3d(0, 0, 0);
      -webkit-transform: translate3d(0, 0, 0);
      transform: translate3d(0, 0, 0);
      -webkit-animation: loop 1s linear infinite;
      -moz-animation: loop 1s linear infinite;
      -o-animation: loop 1s linear infinite;
      animation: loop 1s linear infinite;
    }
    @-webkit-keyframes loop {
        0% {
            -moz-transform: translateX(0);
            -ms-transform: translateX(0);
            -webkit-transform: translateX(0);
            transform: translateX(0);
        }
        100% {
            -moz-transform: translateX(1200%);
            -ms-transform: translateX(1200%);
            -webkit-transform: translateX(1200%);
            transform: translateX(1200%);
        }
    }
    @-moz-keyframes loop {
        0% {
            -moz-transform: translateX(0);
            -ms-transform: translateX(0);
            -webkit-transform: translateX(0);
            transform: translateX(0);
        }
        100% {
            -moz-transform: translateX(1200%);
            -ms-transform: translateX(1200%);
            -webkit-transform: translateX(1200%);
            transform: translateX(1200%);
        }
    }
    @-ms-keyframes loop {
        0% {
            -moz-transform: translateX(0);
            -ms-transform: translateX(0);
            -webkit-transform: translateX(0);
            transform: translateX(0);
        }
        100% {
            -moz-transform: translateX(1200%);
            -ms-transform: translateX(1200%);
            -webkit-transform: translateX(1200%);
            transform: translateX(1200%);
        }
    }
    @keyframes loop {
        0% {
            -moz-transform: translateX(0);
            -ms-transform: translateX(0);
            -webkit-transform: translateX(0);
            transform: translateX(0);
        }
        100% {
            -moz-transform: translateX(1200%);
            -ms-transform: translateX(1200%);
            -webkit-transform: translateX(1200%);
            transform: translateX(1200%);
        }
    }
</style>

<div id="mainNotice">
<div id="mainNoticePop">
<pop-view-pc v-for="(popup, idx) in popList" v-if="!noData" :popup-id="popupId" :key="'popup'+idx" :idx="idx" :item="popup" @popup-close="popupClose"></pop-view-pc>
</div>
</div>
<script src="/common_js/main_notice_v1.js?ver=1.38.2"></script>
<script>
    mainNotice.type='pc';
</script>


<div id="shellWrapper">
<div id="shellMain" style="width: 100%; height: 370px; margin-bottom: 80px; overflow: hidden; background: #eee;">
<div class="shell_ani" style="width: 10%; height: inherit; background: none; background: linear-gradient(to right, rgba(225, 225, 225, 0), rgba(255, 255, 255, .1), rgba(255, 255, 255, 0))"></div>
</div>
<div id="shellSubTitle" style="width: 100%; height: 41px; margin-bottom: 34px;">
<div style="width: 300px; height: 41px; margin: 0 auto; overflow: hidden; background: #eee;">
<div class="shell_ani" style="width: 10%; height: inherit; background: none; background: linear-gradient(to right, rgba(225, 225, 225, 0), rgba(255, 255, 255, .1), rgba(255, 255, 255, 0))"></div>
</div>
</div>
<div id="shellSubContainer" style="width: 1050px; height: 506px; margin: 0 auto 80px;">
<div style="width: 249px; height: 506px; margin-right: 18px; float: left; overflow: hidden;">
<div style="width: 249px; height: 320px; margin-bottom: 11px; overflow: hidden; background: #eee;">
<div class="shell_ani" style="width: 10%; height: 320px; margin-bottom: 11px; background: none; background: linear-gradient(to right, rgba(225, 225, 225, 0), rgba(255, 255, 255, .1), rgba(255, 255, 255, 0))"></div>
</div>
<div style="width: 249px; height: 72px; overflow: hidden; background: #eee;">
<div class="shell_ani" style="width: 10%; height: 72px; background: none; background: linear-gradient(to right, rgba(225, 225, 225, 0), rgba(255, 255, 255, .1), rgba(255, 255, 255, 0))"></div>
</div>
</div>
<div style="width: 249px; height: 506px; margin-right: 18px; float: left; overflow: hidden;">
<div style="width: 249px; height: 320px; margin-bottom: 11px; overflow: hidden; background: #eee;">
<div class="shell_ani" style="width: 10%; height: 320px; margin-bottom: 11px; background: none; background: linear-gradient(to right, rgba(225, 225, 225, 0), rgba(255, 255, 255, .1), rgba(255, 255, 255, 0))"></div>
</div>
<div style="width: 249px; height: 72px; overflow: hidden; background: #eee;">
<div class="shell_ani" style="width: 10%; height: 72px; background: none; background: linear-gradient(to right, rgba(225, 225, 225, 0), rgba(255, 255, 255, .1), rgba(255, 255, 255, 0))"></div>
</div>
</div>
<div style="width: 249px; height: 506px; margin-right: 18px; float: left; overflow: hidden;">
<div style="width: 249px; height: 320px; margin-bottom: 11px; overflow: hidden; background: #eee;">
<div class="shell_ani" style="width: 10%; height: 320px; margin-bottom: 11px; background: none; background: linear-gradient(to right, rgba(225, 225, 225, 0), rgba(255, 255, 255, .1), rgba(255, 255, 255, 0))"></div>
</div>
<div style="width: 249px; height: 72px; overflow: hidden; background: #eee;">
<div class="shell_ani" style="width: 10%; height: 72px; background: none; background: linear-gradient(to right, rgba(225, 225, 225, 0), rgba(255, 255, 255, .1), rgba(255, 255, 255, 0))"></div>
</div>
</div>
<div style="width: 249px; height: 506px; float: left; overflow: hidden;">
<div style="width: 249px; height: 320px; margin-bottom: 11px; overflow: hidden; background: #eee;">
<div class="shell_ani" style="width: 10%; height: 320px; margin-bottom: 11px; background: none; background: linear-gradient(to right, rgba(225, 225, 225, 0), rgba(255, 255, 255, .1), rgba(255, 255, 255, 0))"></div>
</div>
<div style="width: 249px; height: 72px; overflow: hidden; background: #eee;">
<div class="shell_ani" style="width: 10%; height: 72px; background: none; background: linear-gradient(to right, rgba(225, 225, 225, 0), rgba(255, 255, 255, .1), rgba(255, 255, 255, 0))"></div>
</div>
</div>
</div>
</div>
<div id="kurlyMain" class="page_aticle page_main" v-cloak>
<h2 class="screen_out">�����ø� ����</h2>
<component-printer v-for="section in mainData" :section="section" :type="type" :component-name="typeToComponent(section.section_type)"></component-printer>
</div>
<div class="bg_loading" id="bgLoading" style="display:block">
<div class="loading_show"></div>
</div>
<script src="https://res.kurly.com/js/lib/moment.min.js"></script>
<script src="https://res.kurly.com/js/lib/jquery.bxslider.min.js"></script>
<script src="/common_js/common_filter.js?ver=1.38.2"></script>
<script src="/common_js/main_v1.js?ver=1.38.2"></script>
<script>
$(document).ready(function(){
    kurlyMain.type = 'pc';
    kurlyMain.update();

    // GNB Logo checking
    chkGNBLogo('pc');
});
</script>
</div>
</div>

<div id="layerDSR">
<div class="bg_dim"></div>
<div class="in_layer">
<div class="inner_layer layer_star">
<strong class="dsr_result">������� �����Դϴ�.</strong>
<div class="ani">
<img data-src="https://res.kurly.com/mobile/img/1908/img_delivery_kurly.png" src="https://res.kurly.com/mobile/service/common/bg_1x1.png" alt="������� �̹���">
</div>
<p class="dsr_desc default_cutoff_23_7">
<strong class="emph">���� �� 11�� ��</strong>���� �ֹ���<br>
<strong class="emph">������ ��ħ 7��</strong> ���� �����մϴ�!
</p>
<p class="dsr_desc early_cutoff_20_8">
<strong class="emph">���� �� 8�� ��</strong>���� �ֹ���<br>
<strong class="emph">������ ��ħ 8��</strong> ���� �����մϴ�!
</p>
</div>
<div class="inner_layer layer_normal">
<strong class="dsr_result">�ù��� �����Դϴ�.</strong>
<div class="ani">
<img data-src="https://res.kurly.com/mobile/img/1908/img_delivery_car.png" src="https://res.kurly.com/mobile/service/common/bg_1x1.png" alt="�ù��� �̹���">
</div>
<p class="dsr_desc">
<strong class="emph">�� 8�� ��</strong>���� �ֹ���<br>
<strong class="emph">������</strong> �����մϴ�!
</p>
<p class="dsr_notice">�Ͽ����� ��� �޹��� ����Ͽ��� �ֹ� �Ұ�</p>
</div>
<div class="inner_layer layer_none">
<strong class="dsr_result">��� �Ұ� �����Դϴ�.</strong>
<div class="ani">
<img data-src="https://res.kurly.com/mobile/img/1908/img_delivery_none.png" src="https://res.kurly.com/mobile/service/common/bg_1x1.png" alt="��ۺҰ� �̹���">
</div>
<p class="dsr_desc">
<strong class="emph">���θ� �ּ�</strong>�� �˻��ϼ̴ٸ�,<br>
<strong class="emph">���� �ּ�(�� �ּ�)</strong>�� �ٽ� �õ��� �ּ���.
</p>
<p class="dsr_notice">��������� Ȯ���ϵ��� ����ϰڽ��ϴ�!</p>
</div>
<div class="layer_btn1">
<button type="button" class="btn_close" onclick="$('#layerDSR').hide();$(this).parent().find('.inner_layer').hide();">Ȯ��</button>
</div>
<button type="button" class="layer_close" onclick="$('#layerDSR').hide();$(this).parent().find('.inner_layer').hide();"></button>
</div>
</div>
<div id="footer">
<div class="inner_footer">
<div class="footer_cc">
<h2 class="tit_cc">�����ູ����</h2>
<div class="cc_view cc_call">
<h3><span class="tit">1644-1107</span></h3>
<dl class="list">
<dt>365��������</dt>
<dd>���� 7�� - ���� 7��</dd>
</dl>
</div>
<div class="cc_view cc_kakao">
<h3><a class="tit" href="#none">īī���� ����</a></h3>
<script type="text/javascript">
							$('.cc_kakao .tit').on('click',function(e){
								e.preventDefault();
                KurlyTracker.setAction('select_bottom_kakao_button').sendData();
								$.ajax({
									type: "GET",
									url: apiDomain+'/v1/mypage/asks/confirm/kakao',
									dataType: 'json',
									success: function(data) {
										if(data.data.ok_button_action_url.indexOf('https://api.happytalk.io/') > -1){
											if(confirm('['+data.data.title+'] '+data.data.message)) window.open(data.data.ok_button_action_url,'_blank');
										}else{
											alert(data.data.title+'\n'+data.data.message);
										}
									}
								})
							});
						</script>
<dl class="list">
<dt>365��������</dt>
<dd>���� 7�� - ���� 7��</dd>
</dl>
</div>
<div class="cc_view cc_qna">
<h3><a href="#none" onclick="KurlyTrackerLink('/shop/mypage/mypage_qna_register.php?mode=add_qna', 'select_bottom_onebyone_button')" class="tit">1:1 ����</a></h3>
<dl class="list">
<dt>24�ð� ���� ����</dt>
<dd>�������� ��ð��� ���������� �亯�ص帮�ڽ��ϴ�.</dd>
</dl>
</div>
</div>
<div class="company">
<ul class="list">
<li><a class="link" href="/shop/introduce/about_kurly.php">�ø��Ұ�</a></li>
<li><a class="link" href="https://www.youtube.com/embed/WEep7BcboMQ?rel=0&showinfo=0&wmode=opaque&enablejsapi=1" onclick="window.open(this.href, 'pop', 'width=1330,height=660,scrollbars=yes');return false;">�ø��Ұ�����</a></li>
<li><a class="link" href="https://marketkurly.recruiter.co.kr/appsite/company/index" target="_blank">����ä��</a></li>
<li><a class="link" href="/shop/service/agreement.php">�̿���</a></li>
<li><a class="link emph" href="/shop/service/private.php">��������ó����ħ</a></li>
<li><a class="link" href="/shop/service/guide.php">�̿�ȳ�</a></li>
</ul>
���θ� (��ȣ) : �ֽ�ȸ�� �ø� <span class="bar">I</span> ����ڵ�Ϲ�ȣ : 261-81-23567 <a href="http://www.ftc.go.kr/bizCommPop.do?wrkr_no=2618123567&apv_perm_no=" target="_blank" class="link">��������� Ȯ��</a>
<br>
����Ǹž� : �� 2018-���ﰭ��-01646 ȣ <span class="bar">I</span> ����������ȣå���� : �̿���
<br>
�ּ� : ����Ư���� ������ ������� 133, 18��(���ﵿ) <span class="bar">I</span> ��ǥ�̻� : �载��
<br>
�������� : <a href="https://forms.gle/oKMAe1SaicqMX3SC9" target="_blank" class="link">���������ϱ�</a> <span class="bar">I</span> ���޹��� : <a href="mailto:business@kurlycorp.com" class="link">business@kurlycorp.com</a>
<br>
ä�빮�� : <a href="mailto:recruit@kurlycorp.com" class="link">recruit@kurlycorp.com</a>
<br>
�ѽ�: 070 - 7500 - 6098 <span class="bar">I</span> �̸��� : <a href="mailto:help@kurlycorp.com" class="link">help@kurlycorp.com</a>
<em class="copy">&copy; KURLY CORP. ALL RIGHTS RESERVED</em>
<ul class="list_sns">
<li>
<a href="https://instagram.com/marketkurly" class="link_sns" target="_blank"><img src="https://res.kurly.com/pc/ico/1810/ico_instagram.png" alt="�����ø� �ν�Ÿ�׷� �ٷΰ���"></a>
</li>
<li>
<a href="https://www.facebook.com/marketkurly" class="link_sns" target="_blank"><img src="https://res.kurly.com/pc/ico/1810/ico_fb.png" alt="�����ø� ���̽��� �ٷΰ���"></a>
</li>
<li>
<a href="http://blog.naver.com/marketkurly" class="link_sns" target="_blank"><img src="https://res.kurly.com/pc/ico/1810/ico_blog.png" alt="�����ø� ���̹����α� �ٷΰ���"></a>
</li>
<li>
<a href="https://m.post.naver.com/marketkurly" class="link_sns" target="_blank"><img src="https://res.kurly.com/pc/ico/1810/ico_naverpost.png" alt="�����ø� ��Ʃ�� �ٷΰ���"></a>
</li>
<li>
<a href="https://www.youtube.com/channel/UCfpdjL5pl-1qKT7Xp4UQzQg" class="link_sns lst" target="_blank"><img src="https://res.kurly.com/pc/ico/1810/ico_youtube.png" alt="�����ø� ��Ʃ�� �ٷΰ���"></a>
</li>
</ul>
</div>
</div>
<div class="footer_link">
<div class="authentication">
<a href="#none" onclick="popup('https://res.kurly.com/pc/img/1909/img_isms.jpg',550,700);return false;" class="mark" target="_blank">
<img src="https://res.kurly.com/pc/ico/2001/logo_isms.png" alt="isms �ΰ�" class="logo">
<p class="txt">
[��������] �����ø� ���θ� ���� ���� �� �<br>
[��ȿ�Ⱓ] 2019.04.01 ~ 2022.03.31
</p>
</a>
<a href="#none" onclick="popup('https://www.eprivacy.or.kr/front/certifiedSiteMark/certifiedSiteMarkPopup.do?certCmd=EP&certNum=2021-EP-R003',527,720);return false;" class="mark" target="_blank">
<img src="https://res.kurly.com/pc/ico/2001/logo_eprivacyplus.png" alt="eprivacy plus �ΰ�" class="logo">
<p class="txt">
����������ȣ ��� ������Ʈ ��<br>
��������ó���ý��� ���� (ePRIVACY PLUS)
</p>
</a>
<a href="#none" onclick="popup('http://pgweb.uplus.co.kr/ms/escrow/s_escrowYn.do?mertid=go_thefarmers',460,550);return false;" class="mark lguplus" target="_blank">
<img src="https://res.kurly.com/pc/service/main/2009/logo_payments.png" alt="payments �ΰ�" class="logo">
<p class="txt">
�������� �����ŷ��� ���� ���� ������ ���� �� ���� ���θ����� ������<br>
�佺 ���̸��� ���ž���(����ũ��) ���񽺸� �̿��Ͻ� �� �ֽ��ϴ�.
</p>
</a>
</div>
</div>
</div>
</div>
</div>

<a href="#top" id="pageTop">�� ���ΰ���</a>
<script>
	$(document).ready(function(){
		var pageTop = {
			$target : $('#pageTop'),
			$targetDefault : 0,
			$scrollTop : 0,
			$window : $(window),
			$windowHeight : 0,
			setTime : 500,
			saveHeight : 0,
			init:function(){
			},
			action:function(){
				var $self = this;
				$self.$windowHeight = parseInt($self.$window.height());
				$self.$window.on('scroll', function(){
					$self.$scrollTop = parseInt($self.$window.scrollTop());
					if($self.$scrollTop >= $self.$windowHeight){
						if(!$self.$target.hasClass('on')){
							$self.position();
							$self.$target.addClass('on');
							$self.showAction();
						}
					}else{
						if($self.$target.hasClass('on')){
							$self.position();
							$self.$target.removeClass('on');
							$self.hideAction();
						}
					}
				});

				$self.$target.on('click', function(e){
					e.preventDefault();
					$self.topAction();
				});
			},
			showAction:function(){
				var $self = this;
				$self.$target.stop().animate({
					opacity:1,
					bottom:$self.saveHeight
				}, $self.setTime);
			},
			hideAction:function(){
				var $self = this;
				$self.$target.stop().animate({
					opacity:0,
					bottom:-$self.$target.height()
				}, $self.setTime);
			},
			topAction:function(){
				var $self = this;
				$self.hideAction();
				$('html,body').animate({
					scrollTop:0
				}, $self.setTime);
			},
			position:function(){
				var $self = this;
				$self.saveHeight = 15;
				if($('#sectionView').length > 0){
					$self.saveHeight = 25;
				}
				if($('#branch-banner-iframe').length > 0 && parseInt( $('#branch-banner-iframe').css('bottom') ) > 0){
					$('#footer').addClass('bnr_app');
					$self.saveHeight += $('#branch-banner-iframe').height();
				}
			}
		}
		pageTop.action();
	});
</script>

<script>
// Ŭ�����ΰ��(Ǫ�Ϳ� ������, ���������۾��� ����) => bgLoading �̺κ� ó���ʿ�
var bodyScroll = {
	winScrollTop : 0,
	body : $('body'),
	gnb : $('#gnb'),
	bg : $('#bgLoading'),
	bodyFixed : function(){
		var $self = this;
		var gnbCheck = false;
		$self.gnb = $('#gnb');
		if($self.gnb.hasClass('gnb_stop')){
			gnbCheck = true;
		}
		$self.body = $('body');
		$self.bg = $('#bgLoading');
		$self.winScrollTop = $(window).scrollTop();
		$self.bg.show();
		$self.body.addClass('noBody').css({
			'top' : -$self.winScrollTop
		});
	},
	bodyDefault : function(type){
		var $self = this;
		$self.body.removeClass('noBody').removeAttr('style');
		$self.bg.hide();
		if(type === undefined){
			window.scrollTo(0, $self.winScrollTop);
		}
	}
}
</script>

<iframe name="ifrmHidden" id="ifrmHidden" src="about:blank" style="display:none;width:100%;height:600px;"></iframe>
<script>
(function (theFrame) {
  theFrame.contentWindow.location.href = theFrame.src;
}(document.getElementById("ifrmHidden")));
</script>


<script src="https://res.kurly.com/js/polifill/customeEvent.js"></script>
<script>
	window.addEventListener('load', function () {
		// KM-1238 branch
		(function(b,r,a,n,c,h,_,s,d,k){if(!b[n]||!b[n]._q){for(;s<_.length;)c(h,_[s++]);d=r.createElement(a);d.async=1;d.src="https://cdn.branch.io/branch-latest.min.js";k=r.getElementsByTagName(a)[0];k.parentNode.insertBefore(d,k);b[n]=h}})(window,document,"script","branch",function(b,r){b[r]=function(){b._q.push([r,arguments])}},{_q:[],_v:1},"addListener applyCode autoAppIndex banner closeBanner closeJourney creditHistory credits data deepview deepviewCta first getCode init link logout redeem referrals removeListener sendSMS setBranchViewData setIdentity track validateCode trackCommerceEvent logEvent disableTracking".split(" "), 0);
    var BRANCHKEY = 'key_live_meOgzIdffiVWvdquf7Orkacksxa2LneN';
    if(!webStatus.is_release_build){
      BRANCHKEY = 'key_test_joIkrHgomhL3qaEreXL5QdigzEn6Ucd4';
    }
    branch.init(BRANCHKEY);
		branch.setIdentity(uuidCheck);
		branch.track("pageview");

		// branchReady
		var _eventBranchReady = new CustomEvent("branchReady", {
			detail:{ // ���� �Ҳ� ������ �ݵ�� detail ������Ʈ�� �־�� ��
				val:'1',
			}
		});
		document.dispatchEvent(_eventBranchReady);
		// END branchReady
	}, false);
</script>





<script src="/asset/js/useKurly/event/imc202102.bundle.js?ver=1.38.2"></script>
</body>
</html>